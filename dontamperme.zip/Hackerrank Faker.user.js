// ==UserScript==
// @name         Hackerrank Faker
// @namespace    http://tampermonkey.net/
// @version      2024-10-24
// @description  Hackerrank Faker
// @author       BloP
// @match        https://www.hackerrank.com/domains/java*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=hackerrank.com
// @grant        none
// ==/UserScript==

(function() {
    function waitForElement(selector, callback) {
        var interval = setInterval(function() {
            var element = document.querySelector(selector);
            if (element) {
                clearInterval(interval);
                callback(element);
            }
        }, 100);
    }

    waitForElement("#toast-portal-container", function(element) {
        Array.from(document.querySelectorAll(".challenge-submit-btn > button > div > span")).forEach(element => {
            if (element.innerHTML != "Solved") {
                const newIcon = document.createElement("i");
                newIcon.classList.add("ui-icon-check-circle", "ui-btn-icon");
                element.innerHTML = "Solved";
                element.parentElement.classList.add("has-icon");
                element.parentElement.appendChild(newIcon);
            }
        });

        document.querySelector(".recommended-challenge.pjB").remove();
    });
})();