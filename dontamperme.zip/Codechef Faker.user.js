// ==UserScript==
// @name         Codechef Faker
// @namespace    http://tampermonkey.net/
// @version      2024-10-24
// @description  Codechef Faker
// @author       BloP
// @match        https://www.codechef.com/learn/course/java
// @icon         https://www.google.com/s2/favicons?sz=64&domain=codechef.com
// @grant        none
// ==/UserScript==

(function() {
    addEventListener("keydown", function(event) {
        Array.from(document.getElementsByClassName("_lessonStatusIconNotDone_ser9v_570")).forEach(element => {
            element.className = "_lessonStatusIconDone_ser9v_564";
        });
        const pA = [ 100, 38, 65, 33, 58, 23, 68, 42, 73, 50, 100];
        Array.from(document.getElementsByClassName("_progressBar_ser9v_1073")).forEach((element, i) => {
            if (pA[i] == undefined) pA[i] = 100;
            element.setAttribute("style", 'background: radial-gradient(closest-side, white 85%, transparent 80%, transparent 100%), conic-gradient(rgb(43, 190, 98) '
                                 + pA[i]
                                 + '%, rgb(238, 238, 238) 0deg);');
        });
        Array.from(document.getElementsByClassName("_mCard__progress_ser9v_583")).forEach((element, i) => {
            element.innerHTML = pA[i] + "% Solved";
            element.setAttribute('data-value', pA[i]);
        });
        document.getElementsByClassName("_line_ser9v_227")[0].setAttribute("style", "width: 56%;");
        document.getElementsByClassName("_mHead14_ser9v_976")[1].innerHTML = "56 %";
    });
})();